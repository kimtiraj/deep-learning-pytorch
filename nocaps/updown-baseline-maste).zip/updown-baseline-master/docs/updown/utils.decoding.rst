updown.utils.decoding
=====================

.. automodule:: updown.utils.decoding
