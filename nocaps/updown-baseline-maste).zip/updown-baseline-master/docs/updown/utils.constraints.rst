updown.utils.constraints
========================

.. automodule:: updown.utils.constraints
