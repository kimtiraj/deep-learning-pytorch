updown.modules.attention
========================

.. automodule:: updown.modules.attention
