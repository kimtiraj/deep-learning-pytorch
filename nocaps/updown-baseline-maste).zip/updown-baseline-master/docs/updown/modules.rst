updown.modules
==============

.. toctree::

    modules.attention
    modules.cbs
    modules.updown_cell
