updown.data.datasets
====================

.. automodule:: updown.data.datasets
