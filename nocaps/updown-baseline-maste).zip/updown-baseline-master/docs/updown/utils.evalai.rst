updown.utils.evalai
===================

.. automodule:: updown.utils.evalai
