updown.models.updown_captioner
==============================

.. automodule:: updown.models.updown_captioner
