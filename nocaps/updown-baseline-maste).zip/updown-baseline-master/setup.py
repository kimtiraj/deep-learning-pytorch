#!/usr/bin/env python
from setuptools import setup


setup(
    name="updown",
    version="0.1.0",
    author="nocaps team",
    description="Up-Down Captioner Baseline for nocaps.",
    license="MIT",
    zip_safe=True,
)
